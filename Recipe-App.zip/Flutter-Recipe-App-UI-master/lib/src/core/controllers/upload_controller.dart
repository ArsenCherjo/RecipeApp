import 'package:flutter/material.dart';
import 'package:get/get.dart';

class UploadController extends GetxController {
  final foodName = TextEditingController();
  final description = TextEditingController();
  final ingredient = TextEditingController();
}
